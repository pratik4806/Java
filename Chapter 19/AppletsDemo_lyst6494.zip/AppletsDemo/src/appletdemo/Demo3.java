/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appletdemo;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Deepak
 */
public class Demo3 extends Applet implements Runnable
{
    Thread t;
    
    boolean b=true;
    
    int x=100, y=100;
    
    public void start()
    {
        setSize(800,600);
        setBackground(Color.yellow);
        
        t=new Thread(this);
        t.start();
    }
    
    public void paint(Graphics g)
    {
        g.fillOval(x, y, 50, 50);
    }
    
    public void run()
    {
        //System.out.println("hiiiii");
        
        while(b)
        {
            try
            {
                Thread.sleep(100);
                x=x+5;
                y=y+5;
                
//                System.out.println("x : "+x);
//                System.out.println("y : "+y);
//                System.out.println("-----------------------------");
                
                if(x==550 && y==550)
                {
                    b=false;
                }
                
                repaint();
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
    }
}
