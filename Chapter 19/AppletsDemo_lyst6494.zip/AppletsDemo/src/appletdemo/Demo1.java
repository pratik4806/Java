/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appletdemo;

import java.applet.Applet;
import java.awt.Color;

/**
 *
 * @author Deepak
 */
public class Demo1 extends Applet
{
    public void start()
    {
        setSize(800,600);
        setBackground(Color.yellow);
    }
}
