/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appletdemo;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

/**
 *
 * @author Deepak
 */
public class Demo4Image extends Applet
{
    Image img;
    
    public void start()
    {
        setSize(600,600);
        setBackground(Color.yellow);
        
        img=getImage(getDocumentBase(), "redcar.png");
    }
    public void paint(Graphics g)
    {
        g.drawImage(img, 100, 100, this);
    }
}
