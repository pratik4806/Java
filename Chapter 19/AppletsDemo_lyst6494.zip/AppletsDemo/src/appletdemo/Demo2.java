/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appletdemo;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.text.StyleConstants;

/**
 *
 * @author Deepak
 */
public class Demo2 extends Applet
{
    @Override
    public void start()
    {
        setSize(800,600);
        setBackground(Color.yellow);
    }
    
    @Override
    public void paint(Graphics g)
    {
        //creating strings in applets
        g.setFont(new Font("Arial", Font.ITALIC, 20));
        g.drawString("My First Applet program", 50, 50);
        
        //draw lines
        g.drawLine(60, 60, 200, 200);
        g.drawLine(250, 60, 250, 200);
        g.drawLine(300, 60, 500, 60);
        
        //draw circle
        g.drawOval(60, 250, 100, 100);
        g.setColor(Color.red);
        g.fillOval(300, 250, 100, 100);
        
        //draw oval
        g.drawOval(60, 400, 50, 200);
        
        //draw rectangle
        g.setColor(Color.black);
        g.fillRect(300, 400, 200, 100);
    }
}