/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

/**
 *
 * @author Deepak
 */
public class Task5CarGameDesign extends Applet
{
    Image img;
    public void start()
    {
        setSize(1200,900);
        setBackground(Color.green);
        
        img=getImage(getDocumentBase(), "caryellow.png");
    }
    public void paint(Graphics g)
    {
        g.fillRect(300, 0, 600, 900);
        
        g.setColor(Color.white);
        g.fillRect(575, 100, 50, 200);
        g.fillRect(575, 400, 50, 200);
        g.fillRect(575, 700, 50, 200);
        g.fillRect(575, 1000, 50, 200);
        
        g.drawImage(img, 700, 800, this);
    }
}
