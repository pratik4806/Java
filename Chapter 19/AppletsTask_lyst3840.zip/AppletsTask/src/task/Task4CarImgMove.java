/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

/**
 *
 * @author Deepak
 */
public class Task4CarImgMove extends Applet implements Runnable
{
    Thread t;
    
    Image img;
    
    int car_x=100;
    
    public void start()
    {
        setSize(600,600);
        setBackground(Color.yellow);
        
        img=getImage(getDocumentBase(), "redcar.png");
        
        t=new Thread(this);
        t.start();
    }
    public void paint(Graphics g)
    {
        g.drawImage(img, car_x, 100, this);
    }
    
    public void run()
    {
        while(true)
        {
            try
            {
                Thread.sleep(100);
                car_x=car_x+5;
                
                repaint();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}
